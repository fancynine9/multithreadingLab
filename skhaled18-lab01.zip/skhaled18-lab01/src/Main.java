// Main for running all programs on
public class Main {

  public static void main(String args[]) {

      // Program 1

      /*Thread t1 = new Thread(new Program1("t1"));
      Thread t2 = new Thread(new Program1("t2"));
      Thread t3 = new Thread(new Program1("t3"));

       t1.start();
       t2.start();
       t3.start();*/

      // Program 2

     /* Program2 p_1 = new Program2(111, "t1");
      Program2 p_2 = new Program2(222, "t2");
      Program2 p_3 = new Program2(333, "t3");

      Thread t1 = new Thread(p_1);
      Thread t2 = new Thread(p_2);
      Thread t3 = new Thread(p_3);

      t1.start();
      t2.start();
      t3.start(); */

    // Program 3
     /* Program3 p3 = new Program3(0);
      Runner r1 = new Runner(p3, 20);
      Runner r2 = new Runner(p3, 5);

      Thread t1 = new Thread(r1);
      Thread t2 = new Thread(r2);

      t1.start();
      t2.start(); */

      // Program 4 - deadlock w semaphore

    /*Program4 p4 = new Program4(10);

    Runner4 r1 = new Runner4(p4, 11, true);
    Runner4 r2 = new Runner4(p4, 13, false);

    Thread t1 = new Thread(r1);
    Thread t2 = new Thread(r2);

    t1.start();
    t2.start();*/

    // Program 5

    /*Shared5 s1 = new Shared5();
    Shared5 s2 = new Shared5();


    Thread t1 = new Thread1(s1, s2);
    Thread t2 = new Thread2(s1, s2);

    t1.start();
    t2.start();*/

    // Program 6
    // note: i'm pretty sure A is starving B. but it is still
    // a program similar to program4 that does not deadlock
    /*Program6 p6 = new Program6(12);

    Runner6 r1 = new Runner6(p6, 55, true);
    Runner6 r2 = new Runner6(p6, 44,  false);

    Thread t1 = new Thread(r1);
    Thread t2 = new Thread(r2);

    t1.start();
    t2.start();*/

    // Program 7
    Shared7 s1 = new Shared7();
    Shared7 s2 = new Shared7();

    Thread t1 = new Thread7a(s1, s2);
    Thread t2 = new Thread7b(s1, s2);

    t1.start();
    t2.start();


    // Program 8
    /*Queue q = new Queue();

    Consumer consumer = new Consumer(q);
    Producer producer = new Producer(q);

    Thread t1 = new Thread(consumer);
    Thread t2 = new Thread(producer);

    t1.start();
    t2.start();*/
  }


}
