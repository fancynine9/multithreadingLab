public class Shared5 {

// first synchronized method
    public synchronized void test1(Shared5 p5) {

        // this should make test2-start print but it's printing
        // test1-start twice. is the same thread trying to re-start?
        System.out.println("test1-start");
        //p5.test2();
        try {

            Thread.sleep(1000);
            p5.test2();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("test1-end");

    }

    // second synchronized method - no parameters
    public synchronized void test2() {
        System.out.println("test2-start");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("test2-end");
    }




}
