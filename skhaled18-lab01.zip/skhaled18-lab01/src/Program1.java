public class Program1 implements Runnable {

    // variable to modify
    int val = 0;
    String name;

    public Program1(String name) {
        this.name = name;
        this.val = 0;
    }

    @Override
    public void run() {
        // loop for race condition
        while(true){

            // increment val by 1 when run
            System.out.println(name + " " + "add" + " " + val);
            val++;

            // decrement val by 1 on start
            System.out.println(name + " " + "minus" + " " + val);
            val--;
        }
    }
}
