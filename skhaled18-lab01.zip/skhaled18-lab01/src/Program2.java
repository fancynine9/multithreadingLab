// Program 2
public class Program2 implements Runnable {

    static int x;
    private int val = 0;
    private String name;

    public Program2 (int val, String name) {
        this.val = val;
        this.name = name;
    }

    public static synchronized void math(int val, String name) {
        add30();
        int local = x;
        local = local + val;
        x = local;

    }

    // synchronized method
    public static synchronized void add30() {

        for(int i = 0; i < 30; i++) {
            x += 1;
        }
    }

    @Override
    public void run() {
        while(true){

            System.out.println(name + " " + x);
            // x+=val
            math(val, name);

            System.out.println(name + " " + x);

        }

    }
}
