public class Runner4 implements Runnable {

    Program4 p4;
    int amt;
    // will tell runner which alg to use
    boolean b;


    public Runner4(Program4 p4, int amt, boolean b) {
        this.p4 = p4;
        this.amt = amt;
        this.b = b;

    }
    @Override
    public void run() {
        while(true) {
            if(this.b == true){
                int local = p4.incXa(amt);
                System.out.println("A " + "Amount: " + amt + " Local: " + local);
            }
            else {
                int local = p4.incXb(amt);
                System.out.println("B " + "Amount: " + amt + " Local: " + local);
            }


        }
    }
}
