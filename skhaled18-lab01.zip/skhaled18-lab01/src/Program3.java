import java.util.concurrent.Semaphore;

public class Program3 {
    Semaphore s;
    int x = 0;

    public Program3(int x) {
        this.x = x;
        s = new Semaphore(1);
    }

    public int incX(int amt) {
        try {
            // up on semaphore
            s.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
            // quits if fail
            return 0;
        }

        // CS
        this.x += amt;
        int local = this.x;
        // end of CS

        // down on semaphore
        s.release();
        return local;

    }
}
