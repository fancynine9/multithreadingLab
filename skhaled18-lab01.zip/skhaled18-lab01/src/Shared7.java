public class Shared7 {
    // first synchronized method
    public synchronized void test1(Shared7 p7) {
        System.out.println("test1-start");

        p7.test2();

        // sleep so test1 can let go of lock
       try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();

        }

        System.out.println("test1-end");

    }

    // second synchronized method - no parameters
    public synchronized void test2() {
        System.out.println("test2-start");

        System.out.println("test2-end");
    }

}
