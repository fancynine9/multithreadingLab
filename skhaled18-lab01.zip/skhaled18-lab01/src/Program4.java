import java.util.concurrent.Semaphore;
public class Program4 {

    static Semaphore a;
    static Semaphore b;
    int x = 0;

    public Program4(int x) {

        this.x = x;
        a = new Semaphore(1);
        b = new Semaphore(1);
    }

    public int incXa(int amt){
        try{
            a.acquire();
            System.out.println("A acquired");
            Thread.sleep(1000);
            b.acquire();
            System.out.println("B acquired");
        } catch (InterruptedException e) {
            e.printStackTrace();
            return 0;
        }
        // CS
        this.x += amt;
        int local = this.x;

        // if deadlock occurs, these won't print out bc they're never released

            b.release();
            System.out.println("B released");
            a.release();
            System.out.println("A released");


        return local;
    }


    public int incXb(int amt) {

        try {
            b.acquire();
            System.out.println("B Acquired");
            Thread.sleep(1000);
            a.acquire();
            System.out.println("A Acquried");

        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }

        // CS
        this.x += amt;
        int local = this.x;
        // EOCS

        a.release();
        b.release();

        return local;
    }

    /*public int incX(int amt) {
        try {
            b.release();
            a.release();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }

        // CS
        this.x += amt;
        int local = this.x;
        //EOCS

        try {
            a.acquire();
            b.acquire();

        } catch (InterruptedException e) {
            e.printStackTrace();
            return 0;
        }

        return local;
    }*/


}
