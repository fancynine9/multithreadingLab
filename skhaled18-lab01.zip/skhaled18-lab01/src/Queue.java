import java.util.concurrent.Semaphore;
// producer and consumer semaphores
public class Queue {
    int item;

    // made with 0 permits to make sure put() executes 1st
    static Semaphore sConsumer = new Semaphore(0);
    static Semaphore sProducer = new Semaphore(1);

    // gets item from queue
    public void get() {

        // Consumer needs to acquire permit from sConsumer before
        // consuming item
        try {
            sConsumer.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Consumer consumed item: " +  item);

        // After Consumer consumes item,
        // it releases sProducer to notify Producer
        sProducer.release();

    }

    // puts item into queue
    public void put(int item) {


        try {

            // Producer acquires permit from sProducer
            sProducer.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // producer producing item
        this.item = item;

        System.out.println("Producer produced item: " + item);

        // after Producer produces item, releases
        // sConsumer to notify consumer
        sConsumer.release();
    }

}
