// Runner class for program3 data
public class Runner implements Runnable {

    Program3 p3;
    int amt;

    public Runner(Program3 p3, int amt) {
        this.p3 = p3;
        this.amt = amt;
    }
    @Override
    public void run() {
        while(true) {
            int local = p3.incX(amt);
            System.out.println("Amount: " + amt + " Local: " + local);
        }

    }
}
