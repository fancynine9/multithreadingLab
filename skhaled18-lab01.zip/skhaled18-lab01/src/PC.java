// Contains both Producer & Consumer classes

// Producer class
 class Producer implements Runnable {

    Queue q;

    public Producer(Queue q) {

        this.q = q;
    }


    @Override
    public void run() {
        while(true) {
            for(int i = 0; i < 5; i++) {
                // producer puts items
                q.put(i);
            }
        }
    }
}

class Consumer implements Runnable {

    Queue q;

    public Consumer(Queue q) {
        this.q = q;
    }

    @Override
    public void run() {
        while(true) {
            for(int i = 0; i < 5; i++) {
                // consumer gets items
                q.get();
            }
        }
    }
}