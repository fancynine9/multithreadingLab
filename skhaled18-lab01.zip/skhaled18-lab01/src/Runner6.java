public class Runner6 implements Runnable {
    Program6 p6;
    int amt;
    boolean b;


    public Runner6(Program6 p6, int amt, boolean b) {
        this.p6 = p6;
        this.amt = amt;
        this.b = b;

    }
    @Override
    public void run() {
        while(true) {
            if(b == true) {
                int local = p6.incXa(amt);
                System.out.println("A " + "Amount: " + amt + " Local: " + local);
            }
            else {
                int local = p6.incXa(amt);
                System.out.println("A " + "Amount: " + amt + " Local: " + local);
            }




        }
    }
}
