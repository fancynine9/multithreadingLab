public class Thread7b extends Thread {
     Shared7 s1;
     Shared7 s2;

    public Thread7b(Shared7 s1, Shared7 s2) {
        this.s1 = s1;
        this.s2 = s2;
    }

    @Override
    public void run() {
        while(true) {
            s2.test1(s1);
            System.out.println("s2");
        }
    }
}
